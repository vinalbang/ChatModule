import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class ChatService {
  baseURL = "http://localhost:4500/rest/api/chats/"
  

  constructor(private http:HttpClient) { }

   hasConversationsWith(reqBody){
     return this.http.post(this.baseURL+"hasConversationsWith",reqBody);
   }

   getConversationOf(reqBody){
     console.log("req body",reqBody);
      return this.http.post(this.baseURL+"getchatsBetweenUsers",reqBody);
   }

   addNewMessage(reqBody){
     console.log("hahahahaha req body",reqBody);
      return this.http.put(this.baseURL+"addChatsBetweenUsers",reqBody);
   }
}
